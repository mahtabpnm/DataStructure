import java.util.Scanner;

public class CoinChange {
    public static int[] greedyCoinChange(int amount, int[] denominations) {
        int[] coinsUsed = new int[denominations.length];  // Array to store the count of each coin denomination
        
        for (int i = 0; i < denominations.length; i++) {
            coinsUsed[i] = amount / denominations[i];   // Maximum coins of this denomination
            amount = amount - (coinsUsed[i] * denominations[i]);  // Update remaining amount
        }
        
        return coinsUsed;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the amount in cents
        System.out.print("Enter the amount in cents: ");
        int amount = scanner.nextInt();

        // Prompt the user to enter the number of coin denominations
        System.out.print("Enter the number of coin denominations: ");
        int m = scanner.nextInt();
        int[] denominations = new int[m];
        
        // Prompt the user to enter the coin denominations in descending order
        System.out.println("Enter the coin denominations in descending order:");
        for (int i = 0; i < m; i++) {
            denominations[i] = scanner.nextInt();
        }

        // Calculate the minimum coins needed for the given amount
        int[] result = greedyCoinChange(amount, denominations);

        // Display the result
        System.out.println("To make change for " + amount + " cents:");
        for (int i = 0; i < m; i++) {
            System.out.println(denominations[i] + "-cent coins: " + result[i]);
        }

        // Close the scanner
        scanner.close();
    }
}
